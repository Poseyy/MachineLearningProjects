import numpy as np
import pandas as pd

from sklearn.linear_model import LogisticRegression
from sklearn import datasets

import matplotlib
import matplotlib.pyplot as plt
import seaborn as sns

from keras.models import Sequential
from keras.layers import Dense
from keras.wrappers.scikit_learn import KerasClassifier
from keras.utils import np_utils, plot_model
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import KFold
from sklearn.preprocessing import LabelEncoder, scale, LabelBinarizer
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score

df = pd.read_csv("StudentsPerformance.csv",index_col=0)
# seaborn viz for math score
sns.distplot(df['math score'], bins=30)
plt.xlabel('math score')
plt.ylabel('count')
plt.title('Math Scores')
plt.show()

# seaborn viz for gender difference
df['gender'] = df.index
sns.barplot(x='gender', y='math score', data=df)
plt.show()

# seaborn viz for test prep
sns.barplot(x = 'test preparation course', y = 'math score', data=df)
plt.show()

# seaborn viz for parental education
sns.barplot(x='parental level of education',y='math score', data=df)
plt.xticks(rotation=90)
plt.show()

# seaborn viz for test prep
sns.barplot(x = 'race/ethnicity', y = 'math score', data=df)
plt.show()

# seaborn viz for test prep
sns.barplot(x = 'lunch', y = 'math score', data=df)
plt.show()

Y_reg = df['math score'].values
f = range(0,15)
d = range(15,25)
c = range(25,40)
b = range(40,80)
a = range(80,101)
f2 = [str(x) for x in f]
d2 = [str(x) for x in d]
c2 = [str(x) for x in c]
b2 = [str(x) for x in b]
a2 = [str(x) for x in a]
df.replace(f, 'F', inplace=True)
df.replace(d, 'D', inplace=True)
df.replace(c, 'C', inplace=True)
df.replace(b, 'B', inplace=True)
df.replace(a, 'A', inplace=True)
df.replace('F', '0', inplace=True)
df.replace('D', '1', inplace=True)
df.replace('C', '2', inplace=True)
df.replace('B', '3', inplace=True)
df.replace('A', '4', inplace=True)
# race/ethnicity
df.replace('group A', 0, inplace=True)
df.replace('group B', 1, inplace=True)
df.replace('group C', 2, inplace=True)
df.replace('group D', 3, inplace=True)
df.replace('group E', 4, inplace=True)
# test prep
df.replace('none', 0, inplace=True)
df.replace('completed', 1, inplace=True)
# education replace
df.replace('some high school', 0, inplace=True)
df.replace('high school', 1, inplace=True)
df.replace('some college', 2, inplace=True)
df.replace("associate's degree", 3, inplace=True)
df.replace("bachelor's degree", 4, inplace=True)
df.replace("master's degree", 5, inplace=True)
#df.replace("associate's degree", 3, inplace=True)
# lunch replace
df.replace('free/reduced', 0, inplace=True)
df.replace('standard', 1, inplace=True)

# gender replace
df.replace('male', 0, inplace=True)
df.replace('female', 1, inplace=True)
df

sel_feature = ['lunch','parental level of education', 'test preparation course', 'writing score', 'reading score', 'race/ethnicity', 'gender'] # Select features

Y = df['math score'].values
Y = Y.flatten()

def baseline_model():
    model = Sequential()
    model.add(Dense(8, input_dim=7, activation='relu'))
    model.add(Dense(5, activation='softmax'))
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model

# train model
#X = scale(X)
X = df[sel_feature].values
train = df.sample(frac=0.8, random_state=1) # random pick 80% for training
test = df.sample(frac=0.2, random_state=1)
X_train = train[sel_feature].values
X_test = test[sel_feature].values

X_train = scale(X_train)
X_test = scale(X_test)
print(X_train.shape)
print(X_test.shape)

Y_train = train['math score'] # put last columns in y
Y_test = test['math score']   # put last columns in y

print(Y_train.shape)
print(Y_test.shape)

encoder = LabelEncoder()
encoder.fit(Y_train)
dummy_training = np_utils.to_categorical(Y_train)
encoder.fit(Y_test)
dummy_testing = np_utils.to_categorical(Y_test)
dummy_var = np_utils.to_categorical(Y)
lb = LabelBinarizer()
Y_b = lb.fit_transform(Y_test)
print(dummy_training.shape)
print(dummy_testing.shape)

model = baseline_model()
history = model.fit(X_train,dummy_training,epochs=100,verbose=0)
Y_pred = model.predict_classes(X_test)
Y_pred2 = model.predict(X_test)
plt.plot(history.history['acc'])
plt.ylabel('Accuracy')
plt.xlabel('Epoch')
plt.show()
#print(Y_pred2)
#print(Y_pred)

# build model
def baseline_regression_model():
    # create model
    model = Sequential()
    model.add(Dense(8, input_dim=7, activation='relu'))
    model.add(Dense(6, kernel_initializer='normal', activation='relu'))
    model.add(Dense(1, kernel_initializer='normal'))
    # Compile model
    model.compile(loss='mse', optimizer='adam')
    return model

X = scale(X)
# train model
model2 = baseline_regression_model();
history = model2.fit(X,Y_reg,epochs=100,verbose=0)
y_pred = model2.predict(X)
print(y_pred)

from sklearn.metrics import mean_squared_error
from math import sqrt
m = mean_squared_error(Y, y_pred)
print(sqrt(m))
